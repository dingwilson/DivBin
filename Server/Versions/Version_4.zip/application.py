from flask import Flask, jsonify, request
import Firebase

application = Flask(__name__)

test = [
    {
        'Test': 'Kevin',
        'id': 1
    },
    {
        'Test': 'Wislon',
        'id': 2
    }
]

@application.route('/', methods=['GET'])
def root():
    return 'Hello World'

@application.route('/test', methods=['GET'])
def testRoute():
    return jsonify(test)

@application.route('/postTest', methods=['POST'])
def post():
    content = request.get_json(silent = True)
    print(content)
    return jsonify(content)

@application.route('/lists/<string:id>/<string:item>', methods=['GET'])
def addItemToList(id,item):

    Firebase.addItem(id, item)
    result = {
        id:item
    }

    return jsonify(result)

@application.route('/analyze/<string:str>', methods=['GET'])
def analyze(str):

    items = str.split(',')

    total = 0
    trash = 0
    recycle = 0
    compost = 0
    donate = 0

    # for item in items:
    #     print(Firebase.getTrash(item))
    trashItems = Firebase.getTrash().keys()
    recycleItems = Firebase.getRecycle().keys()
    compostItems = Firebase.getCompost().keys()
    donateItems = Firebase.getDonate().keys()

    for item in items:
        item = item.lower()
        if item in trashItems:
            total += 1
            trash += 1
        elif item in recycleItems:
            total += 1
            recycle += 1
        elif item in compostItems:
            total += 1
            compost += 1
        elif item in donateItems:
            total += 1
            donate += 1
    
    data = {
        "Trash": float(trash)/total,
        "Recycle": float(recycle)/total,
        "Compost": float(compost)/total,
        "Donate": float(donate)/total
    }

    return jsonify(data)


if __name__ == '__main__':
    application.run(debug=True)