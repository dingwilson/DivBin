import requests
import json

FIREBASE_URL = "https://divbin-1782f.firebaseio.com/"

def getTrash(item):
    trashURL = FIREBASE_URL + "Trash/" + item + ".json"
    req = requests.get(trashURL)
    return json.loads(req.content)

def getRecycle(item):
    recycleURL = FIREBASE_URL + "Recycle/" + item + ".json"
    req = requests.get(recycleURL)
    return json.loads(req.content)

def getCompost(item):
    compostURL = FIREBASE_URL + "Compost/" + item + ".json"
    req = requests.get(compostURL)
    return json.loads(req.content)

def getDonate(item):
    donateURL = FIREBASE_URL + "Donate/" + item + ".json"
    req = requests.get(donateURL)
    return json.loads(req.content)

def addItem(category, item):

    putURL = FIREBASE_URL

    # TRASH
    if (category == "trash"): 
        putURL += 'Trash.json'

    # RECYCLE
    elif (category == "recycle"):
        putURL += 'Recycle.json'

    # COMPOST
    elif (category == "compost"):
        putURL += 'Compost.json'

    # DONATE
    elif (category == "donate"):
        putURL += 'Donate.json'

    else:
        return

    data = {
        item: ""
    }

    req = requests.patch(putURL, json.dumps(data))
